from flask import Flask, request, render_template_string, session, redirect, url_for, flash
import re
from datetime import datetime, timedelta
import smtplib
from email.mime.text import MIMEText         
from email.mime.multipart import MIMEMultipart  
import secrets
import sqlite3
import os
from flask import render_template

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)
ADMIN_USERNAME = "admin@gmail.com"
ADMIN_PASSWORD = "Admin123@"

def init_db():
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE if not exists users
                 (id INTEGER PRIMARY KEY, email TEXT UNIQUE, password TEXT, 
                  verified INTEGER DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, status TEXT DEFAULT 'active', failed_attempts INTEGER DEFAULT 0, lock_until TEXT)''')
    c.execute('''CREATE TABLE IF NOT EXISTS otps 
                 (email TEXT, otp TEXT, expires_at TIMESTAMP, PRIMARY KEY(email))''')
    conn.commit()
    conn.close()

init_db()

SMTP_CONFIG = {
    'server': 'smtp.gmail.com',
    'port': 587,
    'email': 'tmpixora@gmail.com',  
    'password': 'ngnlpvymsulrmrcq'    
}

DESIGNS = [
    {'id': 0, 'name': 'Professional Resume', 'type': 'resume', 'fields': ['name', 'email', 'phone', 'experience']},
    {'id': 1, 'name': 'Certificate', 'type': 'certificate', 'fields': ['recipient', 'course', 'date', 'issuer']},
    {'id': 2, 'name': 'Cover Letter', 'type': 'cover', 'fields': ['name', 'email', 'position', 'experience']},
    {'id': 3, 'name': 'Invoice', 'type': 'invoice', 'fields': ['company', 'client', 'items', 'amount']},
    {'id': 4, 'name': 'Business Card', 'type': 'businesscard', 'fields': ['name', 'title', 'phone', 'email']},
    {'id': 5, 'name': 'ID Card', 'type': 'idcard', 'fields': ['name', 'id_number', 'department', 'validity']},
    {'id': 6, 'name': 'Newsletter', 'type': 'newsletter', 'fields': ['title', 'email', 'content', 'author']},
    {'id': 7, 'name': 'Invoice Receipt', 'type': 'receipt', 'fields': ['invoice_no', 'paid_by', 'amount', 'date']},
    {'id': 8, 'name': 'Event Invitation', 'type': 'invitation', 'fields': ['guest_name', 'event_name', 'date', 'venue']},
    {'id': 9, 'name': 'Thank You Letter', 'type': 'thankyou', 'fields': ['recipient', 'from_name', 'reason', 'date']}
]

def is_valid_email(email):
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def is_valid_password(password):
    if len(password) < 8:
        return False, "Password must be at least 8 characters"
    if not re.search(r'[A-Z]', password):
        return False, "Password must contain uppercase letter"
    if not re.search(r'\d', password):
        return False, "Password must contain a number"
    if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        return False, "Password must contain special character"
    return True, "Valid"

def generate_otp():
    return f"{secrets.randbelow(900000) + 100000:06d}"  

def send_otp(email, otp):
    try:
        msg = MIMEMultipart()  
        msg['From'] = SMTP_CONFIG['email']
        msg['To'] = email
        msg['Subject'] = "Your Pixora OTP"
        
        body = f"""
        <html>
        <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <h2 style="color: #007bff;">📄 Pixora</h2>
            <p>Your OTP is: <strong style="font-size: 24px; color: #28a745; letter-spacing: 5px;">{otp}</strong></p>
            <p>This OTP expires in 5 minutes.</p>
        </body>
        </html>
        """
        msg.attach(MIMEText(body, 'html')) 
        
        server = smtplib.SMTP(SMTP_CONFIG['server'], SMTP_CONFIG['port'])
        server.starttls()
        server.login(SMTP_CONFIG['email'], SMTP_CONFIG['password'])
        server.send_message(msg)
        server.quit()
        return True
    except Exception as e:
        print(f"Email error: {e}")
        return False

def admin_required(f):
    def wrap(*args, **kwargs):
        if 'admin' not in session:
            flash('Admin access required!', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    wrap.__name__ = f.__name__
    return wrap 

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        if email == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session.clear()
            session['admin'] = True
            flash('Admin login successful!', 'success')
            return redirect(url_for('admin_dashboard'))

        conn = sqlite3.connect('users.db')
        c = conn.cursor()

        try:
            c.execute(
                "SELECT password, verified, status, failed_attempts, lock_until FROM users WHERE email=?",
                (email,)
            )
            user = c.fetchone()

            if user is None:
                flash('Invalid email or password!', 'error')

            else:
                db_password, verified, status, attempts, lock_until = user

                if lock_until:
                    lock_time = datetime.strptime(lock_until, '%Y-%m-%d %H:%M:%S')
                    if datetime.now() < lock_time:
                        remaining = int((lock_time - datetime.now()).total_seconds())
                        flash(f'⏳ Too many failed attempts. Try again after {remaining} seconds.', 'error')
                        return render_template("login.html")

                if status == 'blocked':
                    flash('❌ Your account has been blocked by the admin.', 'error')

                elif db_password != password:
                    attempts += 1

                    if attempts >= 3:
                        lock_until = (datetime.now() + timedelta(seconds=30)).strftime('%Y-%m-%d %H:%M:%S')
                        c.execute(
                            "UPDATE users SET failed_attempts=?, lock_until=? WHERE email=?",
                            (attempts, lock_until, email)
                        )
                        conn.commit()
                        flash('⛔ Too many failed attempts. Account locked for 30 seconds.', 'error')
                    else:
                        c.execute(
                            "UPDATE users SET failed_attempts=? WHERE email=?",
                            (attempts, email)
                        )
                        conn.commit()
                        flash(f'Invalid password! Attempt {attempts}/3', 'error')

                elif verified != 1:
                    flash('⚠️ Please verify your email before logging in.', 'error')

                else:
                    c.execute(
                        "UPDATE users SET failed_attempts=0, lock_until=NULL WHERE email=?",
                        (email,)
                    )
                    conn.commit()
                    session.clear()
                    session['user'] = email
                    flash('Login successful!', 'success')
                    return redirect(url_for('home'))

        finally:
            conn.close()

    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        if not is_valid_email(email):
            flash('Invalid email format!', 'error')
            return render_template("register.html")
        
        is_valid, msg = is_valid_password(password)
        if not is_valid:
            flash(msg, 'error')
            return render_template("register.html")
        
        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        
        try:
            c.execute("SELECT id FROM users WHERE email=?", (email,))
            if c.fetchone():
                flash('Email already registered!', 'error')
                conn.close()
                return render_template("register.html")
            
            c.execute("INSERT INTO users (email, password) VALUES (?, ?)", (email, password))
            conn.commit()
            session['temp_email'] = email
            
            otp = generate_otp()
            expires_at = (datetime.now() + timedelta(minutes=5)).strftime('%Y-%m-%d %H:%M:%S')
            c.execute("INSERT OR REPLACE INTO otps (email, otp, expires_at) VALUES (?, ?, ?)",
                     (email, otp, expires_at))
            conn.commit()
            
            conn.close()  
            
            if send_otp(email, otp):
                flash('Registration successful! Check your email for OTP.', 'success')
                return redirect(url_for('verify_otp'))
            else:
                conn = sqlite3.connect('users.db')
                c = conn.cursor()
                c.execute("DELETE FROM users WHERE email=?", (email,))
                c.execute("DELETE FROM otps WHERE email=?", (email,))
                conn.commit()
                conn.close()
                flash('Email sending failed. Try again.', 'error')
                
        except sqlite3.IntegrityError:
            conn.close()
            flash('Email already registered!', 'error')
        except Exception as e:
            conn.close()
            flash('Registration failed. Try again.', 'error')
    
    return render_template('register.html')

@app.route('/admin/block/<int:user_id>')
@admin_required
def block_user(user_id):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("UPDATE users SET status='blocked' WHERE id=?", (user_id,))
    conn.commit()
    conn.close()

    flash('User blocked successfully!', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/unblock/<int:user_id>')
@admin_required
def unblock_user(user_id):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("UPDATE users SET status='active' WHERE id=?", (user_id,))
    conn.commit()
    conn.close()

    flash('User unblocked successfully!', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin')
@admin_required
def admin_dashboard():
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("SELECT id, email, verified, status, created_at FROM users")
    users = c.fetchall()
    conn.close()

    return render_template('admindashboard.html', users=users)

@app.route('/admin/delete/<int:user_id>')
@admin_required
def delete_user(user_id):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("DELETE FROM users WHERE id=?", (user_id,))
    conn.commit()
    conn.close()

    flash('User deleted successfully!', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/verify-otp', methods=['GET', 'POST'])
def verify_otp():
    if 'temp_email' not in session:
        flash('Session expired. Please register again.', 'error')
        return redirect(url_for('register'))
    
    email = session['temp_email']
    
    if request.method == 'POST':
        user_otp = request.form['otp'].strip()
        
        if len(user_otp) != 6 or not user_otp.isdigit():
            flash('OTP must be 6 digits!', 'error')
            return render_template("otp.html")
        
        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        try:
            c.execute("SELECT otp, expires_at FROM otps WHERE email=?", (email,))
            result = c.fetchone()
            
            if not result:
                flash('No OTP found. Please register again.', 'error')
            elif result[0] != user_otp:
                flash('Invalid OTP!', 'error')
            else:
                expires_at = datetime.strptime(result[1], '%Y-%m-%d %H:%M:%S')
                if datetime.now() > expires_at:
                    flash('OTP expired! Please request new one.', 'error')
                else:
                    c.execute("UPDATE users SET verified=1 WHERE email=?", (email,))
                    c.execute("DELETE FROM otps WHERE email=?", (email,))
                    conn.commit()
                    
                    session.pop('temp_email', None)
                    session['user'] = email
                    conn.close()
                    
                    flash('✅ Email verified! Welcome to Pixor', 'success')
                    return redirect(url_for('home'))
                    
        except Exception as e:
            flash(f'Verification error: {str(e)}', 'error')
        finally:
            conn.close()
    
    conn = sqlite3.connect('users.db')
    c = conn.cursor()

    otp_info = c.fetchone()
    conn.close()
    
    return render_template('otp.html', current_otp=otp_info[0] if otp_info else None)

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully!', 'success')
    return redirect(url_for('login'))

def login_required(f):
    def wrap(*args, **kwargs):
        if 'user' not in session:
            flash('Please login first!', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    wrap.__name__ = f.__name__
    return wrap

@app.route('/')
@login_required
def home():

    return render_template("home.html", session=session)

@app.route('/preview/<int:design_id>')
@login_required
def preview(design_id):
    if design_id not in [d['id'] for d in DESIGNS]:
        return "❌ Design not found", 404
    
    design = next(d for d in DESIGNS if d['id'] == design_id)
    field_names = design['fields']
    
    form_fields = ''
    for field in field_names:
        placeholder = field.replace('_', ' ').title()
        form_fields += f'<input type="text" id="{field}" placeholder="{placeholder} *" required>\n'
    
    js_field_names = ', '.join([f"'{f}'" for f in field_names])
    
    html = f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>{design['name']}</title>
        <style>
            *{{margin:0;padding:0;box-sizing:border-box;}}
            body{{font-family:'Segoe UI',Arial,sans-serif;background:#f0f2f5;padding:30px;}}
            .container{{display:grid;grid-template-columns:1fr 1fr;gap:40px;max-width:1400px;margin:0 auto;}}
            .form-section{{background:white;padding:40px;border-radius:20px;box-shadow:0 15px 35px rgba(0,0,0,0.1);}}
            .preview-section{{background:white;padding:40px;border-radius:20px;box-shadow:0 15px 35px rgba(0,0,0,0.1);}}
            h1{{color:#2c3e50;margin-bottom:30px;font-size:2.2em;}}
            h2{{color:#007bff;margin-bottom:20px;}}
            input,textarea{{width:100%;padding:15px;margin-bottom:20px;border:2px solid #e9ecef;border-radius:12px;font-size:16px;font-family:inherit;transition:border-color 0.3s;}}
            input:focus,textarea:focus{{outline:none;border-color:#007bff;box-shadow:0 0 0 3px rgba(0,123,255,0.1);}}
            button{{width:100%;padding:18px;background:linear-gradient(135deg,#28a745,#20c997);color:white;border:none;border-radius:12px;font-size:18px;font-weight:600;cursor:pointer;transition:all 0.3s;}}
            button:hover{{transform:translateY(-2px);box-shadow:0 10px 25px rgba(40,167,69,0.4);}}
            #preview-content{{min-height:500px;border:2px dashed #dee2e6;padding:30px;border-radius:15px;background:#fafbfc;font-size:16px;line-height:1.6;overflow:auto;}}
            #preview-content:empty::before{{content:"Preview appears here as you type...";color:#6c757d;font-style:italic;text-align:center;line-height:500px;display:block;}}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="form-section">
                <h1>{design['name']}</h1>
                <form id="docForm">
                    {form_fields}
                    <button type="submit">🎉 Generate & Print Document</button>
                </form>
            </div>
            <div class="preview-section">
                <h1>Live Preview</h1>
                <div id="preview-content"></div>
            </div>
        </div>
        <script>
            const designId = {design_id};
            const fieldNames = [{js_field_names}];
            
            function getFieldValue(fieldId) {{
                const el = document.getElementById(fieldId);
                return el ? (el.value || `Default ${{fieldId.replace('_', ' ').replace(/\\b(\\w)/g, l => l.toUpperCase())}}`) : '';
            }}
            
            function updatePreview() {{
                let previewHTML = '';
                
                if(designId === 0) {{ 
                    previewHTML = `
                        <div style="max-width:800px;margin:0 auto;padding:40px;background:#f8f9fa;border-radius:15px;box-shadow:0 10px 30px rgba(0,0,0,0.1);">
                            <header style="text-align:center;border-bottom:4px solid #007bff;padding-bottom:25px;margin-bottom:35px;">
                                <h1 style="color:#2c3e50;font-size:2.8em;margin:0;">` + getFieldValue('name') + `</h1>
                                <p style="color:#7f8c8d;font-size:1.2em;margin-top:10px;">` + getFieldValue('email') + ` • ` + getFieldValue('phone') + `</p>
                            </header>
                            <section>
                                <h2 style="color:#2c3e50;border-left:5px solid #007bff;padding-left:20px;margin-bottom:20px;">Professional Experience</h2>
                                <div style="background:white;padding:25px;border-radius:10px;box-shadow:0 5px 15px rgba(0,0,0,0.08);">` + getFieldValue('experience') + `</div>
                            </section>
                        </div>
                    `;
                }} else if(designId === 1) {{ 
                    previewHTML = `
                        <div style="text-align:center;padding:60px;background:linear-gradient(135deg,#28a745,#20c997);color:white;border-radius:25px;box-shadow:0 20px 40px rgba(40,167,69,0.3);">
                            <h1 style="font-size:3.5em;margin-bottom:25px;text-shadow:2px 2px 10px rgba(0,0,0,0.3);">🏆 Certificate</h1>
                            <h2 style="font-size:1.8em;margin-bottom:15px;">Awarded to: <strong>` + getFieldValue('recipient') + `</strong></h2>
                            <p style="font-size:1.3em;margin-bottom:15px;">For completing: ` + getFieldValue('course') + `</p>
                            <p style="font-size:1.2em;">Date: ` + getFieldValue('date') + ` | Issued by: ` + getFieldValue('issuer') + `</p>
                        </div>
                    `;
                }} else if(designId === 2) {{ 
                    previewHTML = `
                        <div style="max-width:700px;margin:0 auto;padding:40px;background:#e3f2fd;border-left:6px solid #2196f3;border-radius:0 15px 15px 0;box-shadow:0 10px 30px rgba(33,150,243,0.2);">
                            <h2 style="color:#1565c0;margin-bottom:25px;">Dear Hiring Manager,</h2>
                            <p style="margin-bottom:20px;font-size:1.1em;">I am excited to apply for the <strong>` + getFieldValue('position') + `</strong> position.</p>
                            <p style="margin-bottom:20px;font-size:1.1em;">` + getFieldValue('name') + ` - ` + getFieldValue('email') + `</p>
                            <p style="margin-bottom:20px;font-size:1.1em;">` + getFieldValue('experience') + `</p>
                            <p style="text-align:right;font-weight:600;color:#1565c0;">Best regards,<br>` + getFieldValue('name') + `</p>
                        </div>
                    `;
                }} else if(designId === 3) {{ 
                    previewHTML = `
                        <div style="max-width:900px;margin:0 auto;padding:40px;background:white;border-radius:15px;box-shadow:0 10px 30px rgba(0,0,0,0.1);">
                            <header style="border-bottom:3px solid #28a745;padding-bottom:20px;margin-bottom:30px;">
                                <h1 style="color:#28a745;font-size:2.5em;margin:0;">💰 INVOICE</h1>
                                <p style="color:#6c757d;font-size:1.1em;">From: ` + getFieldValue('company') + ` | To: ` + getFieldValue('client') + `</p>
                            </header>
                            <div style="background:#f8f9fa;padding:25px;border-radius:12px;margin-bottom:30px;">Items/Services: ` + getFieldValue('items') + `</div>
                            <div style="text-align:right;font-size:1.3em;color:#28a745;font-weight:600;">TOTAL: $` + getFieldValue('amount') + `</div>
                        </div>
                    `;
                }} else if(designId === 4) {{ 
                    previewHTML = `
                        <div style="width:350px;height:200px;margin:0 auto;padding:25px;background:linear-gradient(135deg,#667eea,#764ba2);color:white;border-radius:15px;box-shadow:0 15px 35px rgba(102,126,234,0.4);text-align:center;">
                            <h2 style="font-size:1.8em;margin-bottom:5px;">` + getFieldValue('name') + `</h2>
                            <p style="font-size:1.1em;margin-bottom:8px;">` + getFieldValue('title') + `</p>
                            <p style="font-size:1em;margin-bottom:5px;">` + getFieldValue('phone') + `</p>
                            <p style="font-size:1em;">` + getFieldValue('email') + `</p>
                        </div>
                    `;
                }} else if(designId === 5) {{ 
                    previewHTML = `
                        <div style="width:400px;height:250px;margin:0 auto;background:linear-gradient(135deg,#6495ed,#4169e1);border-radius:20px;box-shadow:0 20px 40px rgba(245,87,108,0.3);padding:30px;color:white;text-align:center;position:relative;overflow:hidden;">
                            <div style="position:absolute;top:20px;left:20px;background:rgba(255,255,255,0.2);padding:8px 15px;border-radius:20px;font-weight:600;">🆔 ID CARD</div>
                            <h1 style="font-size:2.2em;margin-bottom:15px;">` + getFieldValue('name') + `</h1>
                            <p style="font-size:1.2em;margin-bottom:10px;">ID: ` + getFieldValue('id_number') + `</p>
                            <p style="font-size:1.1em;margin-bottom:10px;">` + getFieldValue('department') + `</p>
                            <p style="font-size:1em;">Valid until: ` + getFieldValue('validity') + `</p>
                        </div>
                    `;
                }} else if(designId === 6) {{ 
                    previewHTML = `
                        <div style="max-width:700px;margin:0 auto;padding:40px;background:#fff3cd;border-left:6px solid #ffc107;border-radius:0 15px 15px 0;box-shadow:0 10px 30px rgba(255,193,7,0.2);">
                            <h2 style="color:#856404;margin-bottom:20px;font-size:2em;">` + getFieldValue('title') + `</h2>
                            <p style="margin-bottom:20px;">To: ` + getFieldValue('email') + ` | By: ` + getFieldValue('author') + `</p>
                            <div style="background:white;padding:25px;border-radius:12px;box-shadow:0 5px 15px rgba(0,0,0,0.08);">` + getFieldValue('content') + `</div>
                        </div>
                    `;
                }} else if(designId === 7) {{ 
                    previewHTML = `
                        <div style="max-width:800px;margin:0 auto;padding:40px;background:#e8f5e8;border-radius:15px;box-shadow:0 10px 30px rgba(40,167,69,0.2);">
                            <header style="text-align:center;border-bottom:3px solid #28a745;padding-bottom:20px;">
                                <h1 style="color:#155724;font-size:2.5em;">✅ RECEIPT</h1>
                                <p style="color:#155724;font-size:1.1em;">Invoice #` + getFieldValue('invoice_no') + ` | ` + getFieldValue('date') + `</p>
                            </header>
                            <div style="padding:25px;background:white;border-radius:12px;margin:25px 0;">Paid by: ` + getFieldValue('paid_by') + `<br>Amount: $` + getFieldValue('amount') + `</div>
                            <div style="text-align:center;font-size:1.4em;color:#28a745;font-weight:600;">✓ PAID IN FULL</div>
                        </div>
                    `;
                }} else if(designId === 8) {{ 
                    previewHTML = `
                        <div style="max-width:600px;margin:0 auto;padding:50px;background:linear-gradient(135deg,#ff9a9e,#fecfef);border-radius:25px;box-shadow:0 20px 40px rgba(255,154,158,0.3);text-align:center;color:#c2185b;">
                            <h1 style="font-size:3em;margin-bottom:25px;">🎉 You're Invited!</h1>
                            <h2 style="font-size:1.8em;margin-bottom:20px;">` + getFieldValue('guest_name') + `</h2>
                            <div style="background:rgba(255,255,255,0.9);padding:30px;border-radius:20px;margin:25px 0;font-size:1.2em;">
                                <strong>` + getFieldValue('event_name') + `</strong><br>
                                Date: ` + getFieldValue('date') + `<br>
                                Venue: ` + getFieldValue('venue') + `
                            </div>
                        </div>
                    `;
                }} else {{ 
                    previewHTML = `
                        <div style="max-width:700px;margin:0 auto;padding:45px;background:#fff8e1;border-left:6px solid #ff9800;border-radius:0 20px 20px 0;box-shadow:0 15px 35px rgba(255,152,0,0.2);">
                            <h2 style="color:#e65100;margin-bottom:25px;font-size:2.2em;">🙏 Thank You!</h2>
                            <p style="margin-bottom:20px;">Dear <strong>` + getFieldValue('recipient') + `</strong>,</p>
                            <div style="background:#fff3e0;padding:30px;border-radius:15px;margin:25px 0;">` + getFieldValue('reason') + `</div>
                            <p style="text-align:right;font-weight:600;color:#e65100;">Sincerely,<br>` + getFieldValue('from_name') + `<br>` + getFieldValue('date') + `</p>
                        </div>
                    `;
                }}
                
                document.getElementById('preview-content').innerHTML = previewHTML;
            }}
            
            
            document.getElementById('docForm').addEventListener('submit', function(e) {{
                e.preventDefault();
                let queryString = '';
                fieldNames.forEach(function(field) {{
                    const value = document.getElementById(field).value;
                    queryString += `&${{field}}=` + encodeURIComponent(value);
                }});
                window.open('/print/' + designId + '?' + queryString.substring(1), '_blank');
            }});
            
            fieldNames.forEach(function(id) {{
                const element = document.getElementById(id);
                if (element) {{
                    element.addEventListener('input', updatePreview);
                }}
            }});
            
            updatePreview();
        </script>
    </body>
    </html>
    '''
    return html

@app.route('/print/<int:design_id>')
@login_required
def print_doc(design_id):
    if design_id not in [d['id'] for d in DESIGNS]:
        return "❌ Design not found", 404
    
    design = next(d for d in DESIGNS if d['id'] == design_id)
    field_names = design['fields']
    
    
    values = {field: request.args.get(field, f'Default {field.replace("_", " ").title()}') for field in field_names}
    
    if design_id == 0:  
        content = f'''
        <div style="max-width:800px;margin:40px auto;padding:40px;background:#f8f9fa;border-radius:15px;box-shadow:0 10px 30px rgba(0,0,0,0.1);font-family:'Segoe UI',Arial,sans-serif;">
            <header style="text-align:center;border-bottom:4px solid #007bff;padding-bottom:25px;margin-bottom:35px;">
                <h1 style="color:#2c3e50;font-size:2.5em;margin:0;">{values['name']}</h1>
                <p style="color:#7f8c8d;font-size:1.1em;margin-top:10px;">{values['email']} • {values['phone']}</p>
            </header>
            <section>
                <h2 style="color:#2c3e50;border-left:5px solid #007bff;padding-left:20px;margin-bottom:20px;">Professional Experience</h2>
                <div style="background:white;padding:25px;border-radius:10px;box-shadow:0 5px 15px rgba(0,0,0,0.08);">{values['experience']}</div>
            </section>
        </div>
        '''
    elif design_id == 1:  
        content = f'''
        <div style="text-align:center;padding:60px;background:linear-gradient(135deg,#28a745,#20c997);color:white;border-radius:25px;box-shadow:0 20px 40px rgba(40,167,69,0.3);margin:40px;font-family:'Segoe UI',Arial,sans-serif;">
            <h1 style="font-size:3.5em;margin-bottom:25px;text-shadow:2px 2px 10px rgba(0,0,0,0.3);">🏆 Certificate</h1>
            <h2 style="font-size:1.8em;margin-bottom:15px;">Awarded to: <strong style="font-size:1.3em;">{values['recipient']}</strong></h2>
            <p style="font-size:1.3em;margin-bottom:15px;">For completing: {values['course']}</p>
            <p style="font-size:1.2em;">Date: {values['date']} | Issued by: {values['issuer']}</p>
        </div>
        '''
    elif design_id == 2:  
        content = f'''
        <div style="max-width:700px;margin:40px auto;padding:40px;background:#e3f2fd;border-left:6px solid #2196f3;border-radius:0 15px 15px 0;box-shadow:0 10px 30px rgba(33,150,243,0.2);font-family:'Segoe UI',Arial,sans-serif;">
            <h2 style="color:#1565c0;margin-bottom:25px;">Dear Hiring Manager,</h2>
            <p style="margin-bottom:20px;font-size:1.1em;">I am excited to apply for the <strong>{values['position']}</strong> position.</p>
            <p style="margin-bottom:20px;font-size:1.1em;">{values['name']} - {values['email']}</p>
            <p style="margin-bottom:20px;font-size:1.1em;">{values['experience']}</p>
            <p style="text-align:right;font-weight:600;color:#1565c0;">Best regards,<br>{values['name']}</p>
        </div>
        '''
    elif design_id == 3:  
        content = f'''
        <div style="max-width:900px;margin:0 auto;padding:40px;background:white;border-radius:15px;box-shadow:0 10px 30px rgba(0,0,0,0.1);">
                            <header style="border-bottom:3px solid #28a745;padding-bottom:20px;margin-bottom:30px;">
                                <h1 style="color:#28a745;font-size:2.5em;margin:0;">💰 INVOICE</h1>
                                <p style="color:#6c757d;font-size:1.1em;">{values['company']}-{values['client']}</p>
                            </header>
                            <div style="background:#f8f9fa;padding:25px;border-radius:12px;margin-bottom:30px;">Items/Services: {values['items']} + `</div>
                            <div style="text-align:right;font-size:1.3em;color:#28a745;font-weight:600;">TOTAL: ${values['amount']}</div>
                        </div>
        '''
    elif design_id == 4: 
        content = f'''
         <div style="width:350px;height:200px;margin:0 auto;padding:25px;background:linear-gradient(135deg,#667eea,#764ba2);color:white;border-radius:15px;box-shadow:0 15px 35px rgba(102,126,234,0.4);text-align:center;">
                            <h2 style="font-size:1.8em;margin-bottom:5px;">{values['name']} </h2>
                            <p style="font-size:1.1em;margin-bottom:8px;">{values['title']} </p>
                            <p style="font-size:1em;margin-bottom:5px;">{values['phone']} </p>
                            <p style="font-size:1em;">{values['email']} </p>
                        </div>
        '''
    elif design_id == 5:  
        content = f'''
        <div style="width:400px;height:250px;margin:0 auto;background:linear-gradient(135deg,#6495ed,#4169e1);border-radius:20px;box-shadow:0 20px 40px rgba(245,87,108,0.3);padding:30px;color:white;text-align:center;position:relative;overflow:hidden;">
                            <div style="position:absolute;top:20px;left:20px;background:rgba(255,255,255,0.2);padding:8px 15px;border-radius:20px;font-weight:600;">🆔 ID CARD</div>
                            <h1 style="font-size:2.2em;margin-bottom:15px;">{values['name']} </h1>
                            <p style="font-size:1.2em;margin-bottom:10px;">ID: {values['id_number']}</p>
                            <p style="font-size:1.1em;margin-bottom:10px;">{values['department']} </p>
                            <p style="font-size:1em;">Valid until: {values['validity']} </p>
                        </div>
        '''
    elif design_id == 6:  
        content = f'''
        <div style="max-width:700px;margin:0 auto;padding:40px;background:#fff3cd;border-left:6px solid #ffc107;border-radius:0 15px 15px 0;box-shadow:0 10px 30px rgba(255,193,7,0.2);">
                            <h2 style="color:#856404;margin-bottom:20px;font-size:2em;">{values['title']} </h2>
                            <p style="margin-bottom:20px;">To: {values['email']} | By: {values['author']} </p>
                            <div style="background:white;padding:25px;border-radius:12px;box-shadow:0 5px 15px rgba(0,0,0,0.08);">{values['content']} </div>
                        </div>
        '''
    elif design_id == 7: 
        content = f'''
        <div style="max-width:800px;margin:0 auto;padding:40px;background:#e8f5e8;border-radius:15px;box-shadow:0 10px 30px rgba(40,167,69,0.2);">
                            <header style="text-align:center;border-bottom:3px solid #28a745;padding-bottom:20px;">
                                <h1 style="color:#155724;font-size:2.5em;">✅ RECEIPT</h1>
                                <p style="color:#155724;font-size:1.1em;">Invoice #{values['invoice_no']}  | {values['date']} </p>
                            </header>
                            <div style="padding:25px;background:white;border-radius:12px;margin:25px 0;">Paid by: {values['paid_by']} <br>Amount: ${values['amount']} </div>
                            <div style="text-align:center;font-size:1.4em;color:#28a745;font-weight:600;">✓ PAID IN FULL</div>
                        </div>
        '''
    elif design_id == 8:  
        content = f'''
         <div style="max-width:600px;margin:0 auto;padding:50px;background:linear-gradient(135deg,#ff9a9e,#fecfef);border-radius:25px;box-shadow:0 20px 40px rgba(255,154,158,0.3);text-align:center;color:#c2185b;">
                            <h1 style="font-size:3em;margin-bottom:25px;">🎉 You're Invited!</h1>
                            <h2 style="font-size:1.8em;margin-bottom:20px;">{values['guest_name']} </h2>
                            <div style="background:rgba(255,255,255,0.9);padding:30px;border-radius:20px;margin:25px 0;font-size:1.2em;">
                                <strong>{values['event_name']} </strong><br>
                                Date: {values['date']}<br>
                                Venue: ` {values['venue']} 
                            </div>
                        </div>
        '''
    elif design_id == 9:  
        content = f'''
        <div style="max-width:700px;margin:0 auto;padding:45px;background:#fff8e1;border-left:6px solid #ff9800;border-radius:0 20px 20px 0;box-shadow:0 15px 35px rgba(255,152,0,0.2);">
                            <h2 style="color:#e65100;margin-bottom:25px;font-size:2.2em;">🙏 Thank You!</h2>
                            <p style="margin-bottom:20px;">Dear <strong>{values['recipient']} </strong>,</p>
                            <div style="background:#fff3e0;padding:30px;border-radius:15px;margin:25px 0;">{values['reason']} </div>
                            <p style="text-align:right;font-weight:600;color:#e65100;">Sincerely,<br>{values['from_name']} <br>{values['date']} </p>
                        </div>
        '''
    else:  
        content = f'''
        <div style="max-width:800px;margin:40px auto;padding:40px;background:#f8f9fa;border-radius:15px;box-shadow:0 10px 30px rgba(0,0,0,0.1);font-family:'Segoe UI',Arial,sans-serif;text-align:center;">
            <h1 style="color:#2c3e50;font-size:2.5em;margin-bottom:30px;">{DESIGNS[design_id]['name']}</h1>
            <div style="background:white;padding:30px;border-radius:12px;margin-top:20px;box-shadow:0 5px 15px rgba(0,0,0,0.08);">
        '''
        for field, value in values.items():
            content += f'<p style="margin-bottom:15px;font-size:1.1em;"><strong>{field.replace("_", " ").title()}:</strong> {value}</p>'
        content += '</div></div>'
    
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Print {DESIGNS[design_id]['name']} - Pixora</title>
        <style>
            @media print {{
                body{{margin:0 !important;padding:0 !important;background:white !important;}}
                .print-controls{{display:none !important;}}
            }}
            @page {{ margin: 0.5in; }}
            body{{font-family:'Segoe UI',Arial,sans-serif;margin:0;background:white;font-size:14px;line-height:1.6;}}
            .print-controls{{text-align:center;margin:30px;padding:20px;background:#f8f9fa;border-radius:15px;}}
            button{{padding:15px 30px;margin:0 10px;background:#28a745;color:white;border:none;border-radius:10px;font-size:16px;font-weight:600;cursor:pointer;transition:all 0.3s;}}
            button:hover{{transform:translateY(-2px);box-shadow:0 8px 20px rgba(40,167,69,0.3);}}
            .close-btn{{background:#6c757d;}}
        </style>
    </head>
    <body>
        {content}
        <div class="print-controls">
            <button onclick="window.print()">🖨️ Print / Save as PDF</button>
            <button class="close-btn" onclick="window.close()">❌ Close</button>
        </div>
        <script>
            window.onload = function() {{
                setTimeout(() => {{
                    window.print();
                }}, 1000);
            }};
        </script>
    </body>
    </html>
    '''

if __name__ == '__main__':
    print("🚀 Pixora with Login/OTP - http://127.0.0.1:5000")
    print("📧 UPDATE SMTP_CONFIG with your email credentials first!")
    print("✅ Go to http://127.0.0.1:5000/login")
    app.run(host='127.0.0.1', port=5000, debug=True)